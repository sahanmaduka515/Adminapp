package com.example.adminapp.directionsLib;


/**
 * Created by Vishal on 10/20/2018.
 */

public interface TaskLoadedCallback {
    void onTaskDone(Object... values);
//    void onDistanceTaskDone(mapDistanceObj distance);
//    void onTimeTaskDone(mapTimeObj time);
}
